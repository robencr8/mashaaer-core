"""
RobinAI_Enhanced package
This package makes the main app accessible for Replit deployment.
"""
# Import app from main.py (application is no longer defined in main.py)
from .main import app