from flask import Flask, jsonify
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

@app.route('/')
def index():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Flask App for Replit</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                line-height: 1.6;
            }
            h1 {
                color: #2c3e50;
            }
        </style>
    </head>
    <body>
        <h1>Flask Application for Replit</h1>
        <p>This application follows Replit's recommended structure for Flask apps.</p>
        <p>The server is running and should be accessible via webview.</p>
        <p>Check the <a href="/health">/health</a> endpoint for status information.</p>
    </body>
    </html>
    """

@app.route('/health')
def health():
    return jsonify({
        "status": "ok",
        "message": "Server is healthy"
    })