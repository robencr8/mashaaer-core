#!/bin/bash
echo "Starting ultra-minimal CORS test server..."
python ultra_minimal_server.py
